#pragma once

#include <GL\glew.h>

#include "CommonValues.h"

class Texture
{
public:
	Texture();
	Texture(const char* fileLoc);

	bool LoadTexture();
	bool LoadTextureA();

	void UseTexture();
	void ClearTexture();

	// settings
	/*
	const unsigned int SCR_WIDTH = 800;//Shao added for deferred_Shading
	const unsigned int SCR_HEIGHT = 600;//Shao added for deferred_Shading

	unsigned int gBuffer;//Shao added for deferred_Shading
  
    unsigned int gPosition, gNormal, gAlbedoSpec;//Shao added for deferred_shading
	*/
	~Texture();

private:
	GLuint textureID;
	int width, height, bitDepth;

	const char* fileLocation;
};

